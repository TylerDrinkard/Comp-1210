public class TriangleY {

}