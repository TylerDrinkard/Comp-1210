/**
 * Prints War Eagle three times.
*/ 
public class FirstProgramNewBadForm{/** *  * @param args (not used)*/      
   public 
   static void main(
   String[] 
   args){System.out.println
         ("War Eagle!"); System.out.println("War Eagle!!")
         ;System.out.println("War Eagle!!!");}}