public class Loop_Example1 {
   public static void main(String[] args) {
      double k;
      k = 0.0;
      while ( k != 5 )
      {
         System.out.println(k);
         k = k + 1;
      }
   }
}