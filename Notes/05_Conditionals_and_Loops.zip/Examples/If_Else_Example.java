public class If_Else_Example {

   public static void main(String[] args) {
   
      if (condition1) {
      
      }
      else if (condition2) {
      
      }
      
      // . . .
      
      else if (conditionN) {
      
      } 
      else {
      
      }  
      
      
      if (condition1) {
      
      }
      else 
         if (condition2) {
         
         }
         
         // . . .
         
         else 
            if (conditionN) {
            
            }
            else {
            
            }   
      
   }
}